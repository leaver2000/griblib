 * Ask usage questions on [StackOverflow](https://stackoverflow.com/questions/tagged/cartopy).
 * For less well defined questions, ideas, general discussion or announcements of related projects use the [Google Group](https://groups.google.com/forum/#!forum/scitools-iris).
 * Report bugs, suggest features or view the source code on [GitHub](https://github.com/SciTools/cartopy).
