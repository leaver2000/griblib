.. _installing:


.. include:: ../../INSTALL
