.. _lines_and_polygons:

Lines and polygons
==================

