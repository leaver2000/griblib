Gallery
-------

The following examples show off the functionality of Cartopy. They
illustrate the kinds of things you can do with this library. For
more examples, tutorials, and guides on how to use Cartopy, see
the :doc:`getting started <../getting_started/index>` section.
